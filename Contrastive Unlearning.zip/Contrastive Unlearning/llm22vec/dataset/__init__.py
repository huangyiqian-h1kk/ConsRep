from .E5Data import E5Data
from .Wiki1M import Wiki1M
